module.exports = {
    // API endpoint URL
    apiUrl: "https://gate.whapi.cloud",
    // API token from your channel
    token: "Mpw7gcYoqTbjF2JvMYTJhZEgAursghma",
    // The ID of the group to which we will send the message. Use to find out the ID: https://whapi.readme.io/reference/getgroups
    group: '120363167596599603@g.us',
    // The ID of the product we will send for the example. Create a product in your WhatsApp and find out the product ID: https://whapi.readme.io/reference/getproducts
    product: '6559353560856703',
    // Bot`s URL (for static file). Webhook Link to your server. At ( {server link}/hook ), when POST is requested, processing occurs
    botUrl: "https://dd39-2001-e68-6248-200-e4e7-f1f7-1d7c-3131.ngrok-free.app/hook/juta",
    // Bot's Port (for hook handler). Don't use 443 port.
    port: "80",
    // GoHighLevel Location ID. This is to be replaced accroding to the address of the GHL sub-account
    ghl_location: 'fofub213V3v78j3mhlPA',
    // GoHighLevel Access Token. This is to be replaced with the access token for the Location ID.
    access_token: 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoQ2xhc3MiOiJMb2NhdGlvbiIsImF1dGhDbGFzc0lkIjoiZm9mdWIyMTNWM3Y3OGozbWhsUEEiLCJzb3VyY2UiOiJJTlRFR1JBVElPTiIsInNvdXJjZUlkIjoiNjYyMTJlZGQ2Y2JmMGQ2MmYyNGZkMjkxLWx2NWNnZWVrIiwiY2hhbm5lbCI6Ik9BVVRIIiwicHJpbWFyeUF1dGhDbGFzc0lkIjoiZm9mdWIyMTNWM3Y3OGozbWhsUEEiLCJvYXV0aE1ldGEiOnsic2NvcGVzIjpbImNvbnRhY3RzLnJlYWRvbmx5IiwiY29udGFjdHMud3JpdGUiXSwiY2xpZW50IjoiNjYyMTJlZGQ2Y2JmMGQ2MmYyNGZkMjkxIiwiY2xpZW50S2V5IjoiNjYyMTJlZGQ2Y2JmMGQ2MmYyNGZkMjkxLWx2NWNnZWVrIn0sImlhdCI6MTcxMzY3NzY0Ni44MzQsImV4cCI6MTcxMzc2NDA0Ni44MzR9.JxWJeUBhp8yXRb73IhejM0mkcDx8TJidg5jUlpuZ8OSsCZ39id_S8KjFiE7VY2L5BmLV0f76Je-TXN0qOHFJHQ8AMFhXnHvfxyTUoRfAq-SDEomKg89UuxwsmASohAYEdxv5xffa6_3Jl7GHFB2gTdrXDd9iA2z-cNO6gw4HO8hhLsEMuTaDwMIGkptZ5iQxlyj3iuyqwPKVtx26291HcZwNGeLL-RKfoj_9TEDJWd8KKvxoiGA9fAdkTZoaoSiqrnQC43xfoHxygUszPPq8zqRHMhoexMnuWHZ_hoSVapoL5OR4JMYsKiqfnnVbk6WapL1wPtoX7hRCc4lJ6aZfutG_0iblA70sG8lO20xED6WfA4afANM0zcZ3QOtVUF0yAhnEsjMGLStmCvoA-F2CaIm9SVRErmiYof6cG18hzvKWFvKSWiXT08ohnuRRY6Y61lppk_sl4JRcEODqUGtTY9BRYFk-dAXD4hkzIRlzUcc5pcybZ-0zq4-O3Px-VcfIwnwbkiDrAm7UyE88ARI5Ko_dxpv9ADxSbdcm-X1z8cLonk6He7fwnPaBmZuYuIOh9tdUZPvyrWjO6gxlrVCLs4psSTBUsJJi0wh2ryqIgGhhYvyHRDaBUyDkg85IeJIasUVE-LxG60HPRuMwthMstVH0jTI8PeWvAUGRP4HBLB0',
    // GoHighLevel App ID. Do not change this unless sure
    ghl_id: '66212edd6cbf0d62f24fd291-lv5cgeek',
    // GoHighLevel App Secret. Do no change this unless sure
    ghl_secret: '0970f2d4-9a1e-45f2-a997-3ea6b87ca6c4',
    // GoHighLevel Refresh Token. This is to be automatically updated every 23 hours
    refresh_token: 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoQ2xhc3MiOiJMb2NhdGlvbiIsImF1dGhDbGFzc0lkIjoiZm9mdWIyMTNWM3Y3OGozbWhsUEEiLCJzb3VyY2UiOiJJTlRFR1JBVElPTiIsInNvdXJjZUlkIjoiNjYyMTJlZGQ2Y2JmMGQ2MmYyNGZkMjkxLWx2NWNnZWVrIiwiY2hhbm5lbCI6Ik9BVVRIIiwicHJpbWFyeUF1dGhDbGFzc0lkIjoiZm9mdWIyMTNWM3Y3OGozbWhsUEEiLCJvYXV0aE1ldGEiOnsic2NvcGVzIjpbImNvbnRhY3RzLnJlYWRvbmx5IiwiY29udGFjdHMud3JpdGUiXSwiY2xpZW50IjoiNjYyMTJlZGQ2Y2JmMGQ2MmYyNGZkMjkxIiwiY2xpZW50S2V5IjoiNjYyMTJlZGQ2Y2JmMGQ2MmYyNGZkMjkxLWx2NWNnZWVrIn0sImlhdCI6MTcxMzY3NzY0Ni44NCwiZXhwIjoxNzQ1MjEzNjQ2Ljg0LCJ1bmlxdWVJZCI6ImE0OGY2NTc4LTgyMjgtNDZlYS04ZmFmLTQ3ZTgwNTE2MWM3YyJ9.aVozBsf-XHaTAclIsYYYeMEQI0tyj30TViCRIqzS9v5uIHJRAx7JHoKGIFcqp0RsZft5Gf2RZQLfwSugypz9w6werh-MvoPu4gRctialWt_XRKzts9gFwJvKYdtRColDeikEuthevrWccexnDX-I7txOLKCgSqjy0iQAPE3JnwRftAbXH7ziMAqCMy-jWkq_zdHN3Lgw9ZgfUpvR83DmlHJCa6t9qgHOCvnueyitVXkzeaw26pE4j0KrdXMX9eFkhXcECRUe7AyaHOdhpqGHV73lsFtEeWlvo3_-cTruU1WArPnIs-QDbcMjDIKm7_46OVLnvIP4udh1bHEDGpweTaBdFUdOq9LrVte5rK9NugmRQOtUoCZsEJKXKoa5kkshzNE-vka1Iryk6hkEn0Cn6UXxbsRBSuFpCPGD2etOVa9T-Gd4nHfInNKiJUnGbUzEeMFYgBGqT9b88Dx2ZzyA5MxncTRTOZQqNBGjXrIr0XhEIdNjbanOCjQU9i-A6M_r4YEUUdi0gIdryWOp_6nfuWX3YjgdN6sIUvPXqJ5x-VbkpntrZ_O_bQe8Z5LQ66vIXcDb8TUrvPE0XQU7p-TPcGgyPsvtl-kRN1Y9wxJPg7mMHbZieVlFXKqSN_gLotDwSj_GiqjMu0yu6rwn13JywbWhH3WfalWdE02HZhwfCAk',
    // OpenAI assistant for the project. This is to be replaced with the OpenAI Assistant API key
    project_assistantID: 'asst_MBtnjfDg0HADSDEpWkbTZnGH',
    // OpenAI assistant for checking name. No need to be changed. Only use for checking name in the text
    check_assistantID: 'asst_lMkTF4mTO4aFKTHUUcSQsp1w',
    // OpenAI API key. This is not the assistant api key.
    openAIAPIKey: 'sk-proj-GOrAbO2vgBPtjQh5fcuhT3BlbkFJO5Z7LVTzNREjfE9qsrEB',
}
