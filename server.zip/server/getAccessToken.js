const fs = require('fs');
const querystring = require('querystring');
const https = require('https');

const configFile = 'config.json';

if (fs.existsSync(configFile)) {
    const appConfig = JSON.parse(fs.readFileSync(configFile, 'utf8'));
    console.log(appConfig);
    if (!appConfig) {
        console.error('Error decoding JSON in config file.');
        process.exit(1);
    }

    const { clientId, clientSecret } = appConfig;
    const grantType = 'authorization_code';

    // Get the code from the URL
    const code = appConfig.code; // Assuming the code is passed as a command-line argument
console.log(code);
    getToken(clientId, clientSecret, grantType, code)
        .then(response => {
            console.log(response);
        })
        .catch(error => {
            console.error(error);
        });
} else {
    console.error('Config file not found.');
    process.exit(1);
}

// Function for getting access token 
function getToken(clientId, clientSecret, grantType, code) {
    return new Promise((resolve, reject) => {
        const postData = querystring.stringify({
            'client_id': clientId,
            'client_secret': clientSecret,
            'grant_type': grantType,
            'code': code,
            'user_type': 'Location'
        });

        const options = {
            hostname: 'services.leadconnectorhq.com',
            path: '/oauth/token',
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': postData.length
            }
        };

        const req = https.request(options, res => {
            let data = '';

            res.on('data', chunk => {
                data += chunk;
            });

            res.on('end', () => {
                const responseData = JSON.parse(data);

                if (!responseData) {
                    reject('Error decoding JSON response');
                } else {
                    resolve(responseData);
                }
            });
        });

        req.on('error', error => {
            reject('Request error: ' + error.message);
        });

        req.write(postData);
        req.end();
    });
}
