const fs = require('fs');
const queryString = require('querystring');

const configFile = 'config.json';

const startAuthentication = async () => {
    try {
        // Check if config file exists
        if (fs.existsSync(configFile)) {
            // Read config file
            const configData = JSON.parse(fs.readFileSync(configFile));

            // Check if config data is valid
            if (!configData) {
                throw new Error('Error decoding JSON in config file.');
            }

            const options = {
                requestType: 'code',
                redirectUri: 'http://localhost/80/getAccessToken.js',
                clientId: configData.clientId,
                scopes: [
                    'contacts.readonly',
                    'contacts.write',
                    'conversations.write',
                    'conversations.readonly',
                    'conversations/message.readonly',
                    'conversations/message.write',
                    'conversations/reports.readonly',
                    'opportunities.readonly',
                    'opportunities.write',
                ]
            };

            const redirectUrl = `${configData.baseUrl}/oauth/chooselocation?${queryString.stringify({
                response_type: options.requestType,
                redirect_uri: options.redirectUri,
                client_id: options.clientId,
                scope: options.scopes.join(' ')
            })}`;

            console.log('Redirect URL:', redirectUrl);
            // In a real scenario, you would typically redirect the user to this URL
        } else {
            throw new Error('Config file not found.');
        }
    } catch (error) {
        console.error('Error:', error.message);
    }
};

// Call startAuthentication function
startAuthentication();
