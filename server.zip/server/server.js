const express = require('express');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
const config = require('./config');
require('dotenv').config();

const cors = require('cors');
const app = express();
const admin = require('./firebase.js');
app.use(bodyParser.json());// Middleware
// Serve static files from the 'public' directory
app.use(express.static('dist'));
app.get('/', function (req, res) {
    res.send('Bot is running');
});
app.use(cors());
app.post('/juta/hook', handleNewMessagesJuta);
app.post('/aq/hook', handleNewMessagesAQ);
app.post('/tic/hook', handleNewMessagesTIC);
const port = process.env.PORT;
app.listen(port, function () {
    console.log(`Listening on port ${port}...`);
});

async function createUserInFirebase(userData) {
    try {
      const userRecord = await admin.auth().createUser(userData);
      console.log('Successfully created new user:', userRecord.uid);
      return userRecord.uid;
    } catch (error) {
      console.error('Error creating new user:', error);
      throw error;
    }
  }
  app.post('/api/create-user/:email/:phoneNumber/:password', async (req, res) => {
    try {
      // Extract user data from URL parameters
      console.log(req.params)
      const userData = {
        email: req.params.email,
        phoneNumber: req.params.phoneNumber,
        password: req.params.password,
      };
  
      // Call the function to create a user
      const uid = await createUserInFirebase(userData);
  
      // Send success response
      res.json({ message: 'User created successfully', uid });
    } catch (error) {
      // Handle errors
      console.error('Error creating user:', error);
      res.status(500).json({ error: 'Failed to create user' });
    }
  });
app.get('/api/chats/:token', async (req, res) => {
    const token = req.params.token;
    console.log(token);
    try {
        const response = await fetch('https://gate.whapi.cloud/chats', {
            headers: { 'Authorization': 'Bearer '+token }
        });
        const data = await response.json();
        console.log(data);
        res.json(data);
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/api/messages/:chatId/:token', async (req, res) => {
    const chatId = req.params.chatId;
    const whapiToken = req.params.token; // Access token from query parameters
    console.log('token', req.params);
    try {
        const response = await fetch(`https://gate.whapi.cloud/messages/list/${chatId}`, {
            headers: { 'Authorization':  `Bearer ${whapiToken}` }
        });
        console.log(response);
        const data = await response.json();
        console.log(data);
        res.json(data);
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});
app.post('/api/messages/text/:chatId/:token/:message', async (req, res) => {
    const chatId = req.params.chatId;
    const token = req.params.token; // Access token from query parameters
    const message = req.params.message;
    console.log('token', req.params);
    console.log(req.body);
    try {
        const response = await fetch(`https://gate.whapi.cloud/messages/text`, {
            method: 'POST',
            headers: {
                'Authorization': 'Bearer ' + token,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ to:chatId,body: message })
        });
        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});
async function ghlToken(){
    const encodedParams = new URLSearchParams();
    encodedParams.set('client_id', config.ghl_id);
    encodedParams.set('client_secret', config.ghl_secret);
    encodedParams.set('grant_type', 'refresh_token');
    encodedParams.set('refresh_token', config.refresh_token);
    encodedParams.set('user_type', 'Location');
  
    const options = {
        method: 'POST',
        url: 'https://services.leadconnectorhq.com/oauth/token',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            Accept: 'application/json'
        },
        data: encodedParams,
    };
  
    try {
        const { data } = await axios.request(options);
        await updateAccessToken(data);
    } catch (error) {
        console.error(error);
    }
}
  
async function updateAccessToken(newData) {  
    const configPath = './config.js';
    fs.readFile(configPath, 'utf8', (err, data) => {
      if (err) {
        console.error(err);
        return;
      }
  
      const updatedLines = data.split('\n').map(line => {
        const trimmedLine = line.trim();
        for (const key in newData) {
          if (trimmedLine.startsWith(`${key}:`)) {
            return `${key}: '${newData[key]}',`;
          }
        }
        return line;
      });
  
      const config = `${updatedLines.join('\n')}`;
  
      fs.writeFile(configPath, config, 'utf8', (err) => {
        if (err) {
          console.error(err);
          return;
        }
        console.log('Config file updated successfully');
      });
    });
}
// Define route to add the "Stop bot only" label
app.post('/api/add-label-association/:associationId', async (req, res) => {
    const {associationId } = req.params;
    console.log( associationId);
    
    try {
        const response = await fetch(`https://gate.whapi.cloud/labels/12/${associationId}`, {
            method: 'POST',
            headers: {
                'Authorization': 'Bearer hU4a75eDR92Y3wwEtXvLAqQ1ZaTKNJEX', // Replace with your actual API token
                'Content-Type': 'application/json'
            }
        });
        
        console.log(response);
        const data = await response.json();

        // Send the JSON response
        res.json(data);
    } catch (error) {
        console.error('Error adding label association:', error);
        
        // Send an error response
        res.status(500).send('Internal Server Error');
    }
});
// Define route to remove the "Stop bot only" label
app.delete('/api/delete-label-association/:labelId/:associationId', async (req, res) => {
    const { labelId, associationId } = req.params;
    console.log(labelId, associationId);
    
    try {
        const response = await fetch(`https://gate.whapi.cloud/labels/${labelId}/${associationId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': 'Bearer hU4a75eDR92Y3wwEtXvLAqQ1ZaTKNJEX', // Replace with your actual API token
                'Content-Type': 'application/json'
            }
        });
        
        console.log(response);
        const data = await response.json();

        // Send the JSON response
        res.json(data);
    } catch (error) {
        console.error('Error deleting label association:', error);
        
        // Send an error response
        res.status(500).send('Internal Server Error');
    }
});


async function handleNewMessagesJuta(req, res) {
    const JUTA_AGENT_ID = 'asst_2pYk0Z14FwskCX8UIxDDQmyS';
    try {
        console.log('Handling new messages...');
        const receivedMessages = req.body.messages;

        for (const message of receivedMessages) {
        
            if (message.from_me) break;
          
            if(!message.chat_id.includes("whatsapp")){
                break;
            }
           
           // Call the webhook before sending the response to the user
            console.log(message);
            const sender = {
                to: message.chat_id,
                name:message.from_name
            };

            if (message.type === 'text') {
                console.log('Received text message:', message);

                // Call the webhook before sending the response to the user
                const webhookResponse2 = await callWebhook('https://hook.us1.make.com/ip9bkgkfweqnpkyv1akwkqtgi065y4hp',message.text.body,sender.to,sender.name);

                if(webhookResponse2=== 'stop'||webhookResponse2=== 'Accepted'){
                   break;
               }
                if (webhookResponse2) {
                    // Send the response from the webhook to the user
                    await sendWhapiRequestJuta('messages/text', { to: sender.to, body: webhookResponse2 },);
                } else {
                    console.error('No valid response from webhook.');
                }

                console.log('Response sent.');
            } else if (message.type === 'image') {


                // Call the webhook before sending the response to the user
        const webhookResponse = await callWebhook("https://hook.us1.make.com/8i6ikx22ov6gkl5hvjtssz22uw9vu1dq",message.image.link,sender.to,sender.name);
                if (webhookResponse) {
                    // Send the response from the webhook to the user
                    await sendWhapiRequestJuta('messages/text', { to: sender.to, body: webhookResponse },);
                } else {
                    console.error('No valid response from webhook.');
                }

                console.log('Response sent.');
            } else {
                // Handle non-text messages here
            }
        }

        res.send('All messages processed');
    } catch (e) {
        console.error('Error:', e.message);
        res.send(e.message);
    }
}
async function handleNewMessagesAQ(req, res) {
 
    try {
        console.log('Handling new messages...');
        const receivedMessages = req.body.messages;

        for (const message of receivedMessages) {
        
            if (message.from_me) break;
          
            if(!message.chat_id.includes("whatsapp")){
                break;
            }
           
           // Call the webhook before sending the response to the user
            console.log(message);
            const sender = {
                to: message.chat_id,
                name:message.from_name
            };

            if (message.type === 'text') {
                console.log('Received text message:', message);

                // Call the webhook before sending the response to the user
                const webhookResponse2 = await callWebhook('https://hook.us1.make.com/824gx5fn9kqchpws99d5os8t55ldzh5t',message.text.body,sender.to,sender.name);

                if(webhookResponse2=== 'stop'||webhookResponse2=== 'Accepted'){
                   break;
               }
                if (webhookResponse2) {
                    // Send the response from the webhook to the user
                    await sendWhapiRequestAQ('messages/text', { to: sender.to, body: webhookResponse2 },);
                } else {
                    console.error('No valid response from webhook.');
                }

                console.log('Response sent.');
            } else if (message.type === 'image') {


                // Call the webhook before sending the response to the user
        const webhookResponse = await callWebhook("https://hook.us1.make.com/824gx5fn9kqchpws99d5os8t55ldzh5t",message.image.link,sender.to,sender.name);
                if (webhookResponse) {
                    // Send the response from the webhook to the user
                    await sendWhapiRequestAQ('messages/text', { to: sender.to, body: webhookResponse },);
                } else {
                    console.error('No valid response from webhook.');
                }

                console.log('Response sent.');
            } else {
                // Handle non-text messages here
            }
        }

        res.send('All messages processed');
    } catch (e) {
        console.error('Error:', e.message);
        res.send(e.message);
    }
}
async function handleNewMessagesTIC(req, res) {
 
    try {
        console.log('Handling new messages...');
        const receivedMessages = req.body.messages;

        for (const message of receivedMessages) {
        
            if (message.from_me) break;
          
            if(!message.chat_id.includes("whatsapp")){
                break;
            }
           
           // Call the webhook before sending the response to the user
            console.log(message);
            const sender = {
                to: message.chat_id,
                name:message.from_name
            };

            if (message.type === 'text') {
                console.log('Received text message:', message);

                // Call the webhook before sending the response to the user
                const webhookResponse2 = await callWebhook('https://hook.us1.make.com/824gx5fn9kqchpws99d5os8t55ldzh5t',message.text.body,sender.to,sender.name);

                if(webhookResponse2=== 'stop'||webhookResponse2=== 'Accepted'){
                   break;
               }
                if (webhookResponse2) {
                    // Send the response from the webhook to the user
                    await sendWhapiRequestAQ('messages/text', { to: sender.to, body: webhookResponse2 },);
                } else {
                    console.error('No valid response from webhook.');
                }

                console.log('Response sent.');
            } else if (message.type === 'image') {


                // Call the webhook before sending the response to the user
        const webhookResponse = await callWebhook("https://hook.us1.make.com/824gx5fn9kqchpws99d5os8t55ldzh5t",message.image.link,sender.to,sender.name);
                if (webhookResponse) {
                    // Send the response from the webhook to the user
                    await sendWhapiRequestAQ('messages/text', { to: sender.to, body: webhookResponse },);
                } else {
                    console.error('No valid response from webhook.');
                }

                console.log('Response sent.');
            } else {
                // Handle non-text messages here
            }
        }

        res.send('All messages processed');
    } catch (e) {
        console.error('Error:', e.message);
        res.send(e.message);
    }
}
async function callWebhook(webhook,senderText,senderNumber,senderName) {
    console.log('Calling webhook...');
    const webhookUrl = webhook;
    const body = JSON.stringify({ senderText,senderNumber,senderName }); // Include sender's text in the request body
    const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: body
    });  let responseData =""
    if(response.status === 200){
        responseData= await response.text(); // Dapatkan respons sebagai teks
    }else{
        responseData = 'stop'
    }
    console.log('Webhook response:', responseData); // Log raw response
 return responseData;
}

async function sendWhapiRequestJuta(endpoint, params = {}, method = 'POST') {
    console.log('Sending request to Whapi.Cloud...');
    const options = {
        method: method,
        headers: {
            Authorization: `Bearer hU4a75eDR92Y3wwEtXvLAqQ1ZaTKNJEX`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
    };
    const url = `${config.apiUrl}/${endpoint}`;
    const response = await fetch(url, options);
    const jsonResponse = await response.json();
    console.log('Whapi response:', JSON.stringify(jsonResponse, null, 2));
    return jsonResponse;
}

async function sendWhapiRequestAQ(endpoint, params = {}, method = 'POST') {
    console.log('Sending request to Whapi.Cloud...');
    const options = {
        method: method,
        headers: {
            Authorization: `Bearer chAHFllTq7fdSYil8DIWcS7pE95ajwqk`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
    };
    const url = `${config.apiUrl}/${endpoint}`;
    const response = await fetch(url, options);
    const jsonResponse = await response.json();
    console.log('Whapi response:', JSON.stringify(jsonResponse, null, 2));
    return jsonResponse;
}

async function sendWhapiRequestTIC(endpoint, params = {}, method = 'POST') {
    console.log('Sending request to Whapi.Cloud...');
    const options = {
        method: method,
        headers: {
            Authorization: `Bearer `,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
    };
    const url = `${config.apiUrl}/${endpoint}`;
    const response = await fetch(url, options);
    const jsonResponse = await response.json();
    console.log('Whapi response:', JSON.stringify(jsonResponse, null, 2));
    return jsonResponse;
}
